%%
FileName = 'attitudeCopter';
Order = [6 3 6];
Parameters = [(Iyy-Izz)/Ixx;(Izz-Ixx)/Iyy;(Ixx-Iyy)/Izz];
InitialStates = [0.02108646;-0.04528395;1.93349111;-0.008441;-0.01621525;-0.02754967];
m = idnlgrey(FileName,Order,Parameters,InitialStates,0.25)

%%
set(m,'InputName',{'tau_roll','tau_pitch','tau_yaw'}, ...
    'OutputName',{'Roll','Pitch','Yaw','RollSpeed','PitchSpeed','YawSpeed'})
%%
m.SimulationOptions.AbsTol = 1e-6;
m.SimulationOptions.RelTol = 1e-5;
%compare(drone,m)
m = setinit(m,'Fixed',{false,false,false,false,false,false});
opt = nlgreyestOptions('Display','on');
m = nlgreyest(trainDrone,m,opt)

%%
e1 = eig(ss2.A)
e2 = eig(sysdis2.A)